name(le).
version('0.0.2').
title('Logical English Parser').
author('Jacinto Dávila', 'jd@logicalcontracts.com').
home('https://github.com/LogicalContracts/LogicalEnglish').
